package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Objects;


public class MainActivity extends AppCompatActivity {
    boolean conect_flag = false;
    String str, windowsString;
    Context context = this; // или Context context = this;
    boolean flagText = false;
    private TextView isConnect;
    private Button button1;
    private EditText edittext;
    private EditText textinput0;
    private EditText textinput1;
    private EditText textinput2;
    private EditText textinput3;
    private EditText textinput4;
    private EditText textinput5;
    private EditText textinput6;
    private EditText textinput7;
    private EditText textinput8;
    private EditText textinput9;
    private EditText textinput10;
    private EditText textinput11;
    private EditText textinput12;
    private EditText textinput13;
    private EditText textinput14;

    private void saveTextToFile(String text, File file) {
        text = text.replace("\n", Objects.requireNonNull(System.getProperty("line.separator")));
        try {
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(text.getBytes());
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private String readTextFromFile(File file) {
        try {
            FileInputStream fis = new FileInputStream(file);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line).append(System.lineSeparator()); // добавляем символы перевода строки между строками
            }
            br.close();
            isr.close();
            fis.close();
            return sb.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }


    public static String addCharToString(String str, char c,
                                         int pos)
    {

        // Creating an object of StringBuffer class
        StringBuffer stringBuffer = new StringBuffer(str);

        // insert() method where position of character to be
        // inserted is specified as in arguments
        stringBuffer.insert(pos, c);

        // Return the updated string
        // Concatenated string
        return stringBuffer.toString();
    }

    @Override

    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        isConnect = findViewById(R.id.isConnect);
        button1 = findViewById(R.id.button1);
        edittext = findViewById(R.id.MACadress);
        textinput0 = findViewById(R.id.textinput0);
        textinput0.setTypeface(Typeface.MONOSPACE);
        textinput1 = findViewById(R.id.textinput1);
        textinput1.setTypeface(Typeface.MONOSPACE);
        textinput2 = findViewById(R.id.textinput2);
        textinput2.setTypeface(Typeface.MONOSPACE);
        textinput3 = findViewById(R.id.textinput3);
        textinput3.setTypeface(Typeface.MONOSPACE);
        textinput4 = findViewById(R.id.textinput4);
        textinput4.setTypeface(Typeface.MONOSPACE);
        textinput5 = findViewById(R.id.textinput5);
        textinput5.setTypeface(Typeface.MONOSPACE);
        textinput6 = findViewById(R.id.textinput6);
        textinput6.setTypeface(Typeface.MONOSPACE);
        textinput7 = findViewById(R.id.textinput7);
        textinput7.setTypeface(Typeface.MONOSPACE);
        textinput8 = findViewById(R.id.textinput8);
        textinput8.setTypeface(Typeface.MONOSPACE);
        textinput9 = findViewById(R.id.textinput9);
        textinput9.setTypeface(Typeface.MONOSPACE);
        textinput10 = findViewById(R.id.textinput10);
        textinput10.setTypeface(Typeface.MONOSPACE);
        textinput11 = findViewById(R.id.textinput11);
        textinput11.setTypeface(Typeface.MONOSPACE);
        textinput12 = findViewById(R.id.textinput12);
        textinput12.setTypeface(Typeface.MONOSPACE);
        textinput13 = findViewById(R.id.textinput13);
        textinput13.setTypeface(Typeface.MONOSPACE);
        textinput14 = findViewById(R.id.textinput14);
        textinput14.setTypeface(Typeface.MONOSPACE);

        File directory = new File(getFilesDir(), "my_app_directory");
        directory.mkdirs();

        File filetextinput0 = new File(directory, "textinput0.txt");
        File filetextinput1 = new File(directory, "textinput1.txt");
        File filetextinput2 = new File(directory, "textinput2.txt");
        File filetextinput3 = new File(directory, "textinput3.txt");
        File filetextinput4 = new File(directory, "textinput4.txt");
        File filetextinput5 = new File(directory, "textinput5.txt");
        File filetextinput6 = new File(directory, "textinput6.txt");
        File filetextinput7 = new File(directory, "textinput7.txt");
        File filetextinput8 = new File(directory, "textinput8.txt");
        File filetextinput9 = new File(directory, "textinput9.txt");
        File filetextinput10 = new File(directory, "textinput10.txt");
        File filetextinput11 = new File(directory, "textinput11.txt");
        File filetextinput12 = new File(directory, "textinput12.txt");
        File filetextinput13 = new File(directory, "textinput13.txt");
        File filetextinput14 = new File(directory, "textinput14.txt");

        textinput0.setText(readTextFromFile(filetextinput0));
        textinput1.setText(readTextFromFile(filetextinput1));
        textinput2.setText(readTextFromFile(filetextinput2));
        textinput3.setText(readTextFromFile(filetextinput3));
        textinput4.setText(readTextFromFile(filetextinput4));
        textinput5.setText(readTextFromFile(filetextinput5));
        textinput6.setText(readTextFromFile(filetextinput6));
        textinput7.setText(readTextFromFile(filetextinput7));
        textinput8.setText(readTextFromFile(filetextinput8));
        textinput9.setText(readTextFromFile(filetextinput9));
        textinput10.setText(readTextFromFile(filetextinput10));
        textinput11.setText(readTextFromFile(filetextinput11));
        textinput12.setText(readTextFromFile(filetextinput12));
        textinput13.setText(readTextFromFile(filetextinput13));
        textinput14.setText(readTextFromFile(filetextinput14));

        BluetoothSender sender = new BluetoothSender(context, edittext.getText().toString());

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Действия перед изменением текста
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Действия во время изменения текста
                str = "";
                str += (char)16;

                View view = getCurrentFocus();
                int viewId = view.getId();

                if (viewId == R.id.textinput0) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput0.setText(buf);
                        textinput0.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput0);
                    str += "00";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);

                } else if (viewId == R.id.textinput1) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput1.setText(buf);
                        textinput1.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput1);
                    str += "01";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                } else if (viewId == R.id.textinput2) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput2.setText(buf);
                        textinput2.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput2);
                    str += "02";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                } else if (viewId == R.id.textinput3) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput3.setText(buf);
                        textinput3.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput3);
                    str += "03";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                } else if (viewId == R.id.textinput4) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput4.setText(buf);
                        textinput4.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput4);
                    str += "04";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                } else if (viewId == R.id.textinput5) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput5.setText(buf);
                        textinput5.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput5);
                    str += "05";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                } else if (viewId == R.id.textinput6) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput6.setText(buf);
                        textinput6.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput6);
                    str += "06";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                } else if (viewId == R.id.textinput7) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput7.setText(buf);
                        textinput7.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput7);
                    str += "07";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                } else if (viewId == R.id.textinput8) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput8.setText(buf);
                        textinput8.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput8);
                    str += "08";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                } else if (viewId == R.id.textinput9) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput9.setText(buf);
                        textinput9.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput9);
                    str += "09";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                } else if (viewId == R.id.textinput10) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput10.setText(buf);
                        textinput10.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput10);
                    str += "10";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                } else if (viewId == R.id.textinput11) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput11.setText(buf);
                        textinput11.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput11);
                    str += "11";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                } else if (viewId == R.id.textinput12) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput12.setText(buf);
                        textinput12.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput12);
                    str += "12";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                } else if (viewId == R.id.textinput13) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput13.setText(buf);
                        textinput13.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput13);
                    str += "13";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                } else if (viewId == R.id.textinput14) {
                    String buf="";
                    if (s.toString().length() > 260) {
                        buf = s.toString().substring(0, 260);
                        textinput14.setText(buf);
                        textinput14.setSelection(buf.length());
                    } else {
                        buf = s.toString();
                    }
                    windowsString = buf;

                    saveTextToFile(windowsString, filetextinput14);
                    str += "14";
                    if(windowsString.length() <= 270)
                        str += windowsString;
                    else{
                        str += windowsString.substring(0, 270);
                    }
                    str += (char)17;
                    if(conect_flag)
                        sender.sendMessage(str);
                }

            }

            @Override
            public void afterTextChanged(Editable s) {
                // Действия после изменения текста
            }
        };

        textinput0.addTextChangedListener(textWatcher);
        textinput1.addTextChangedListener(textWatcher);
        textinput2.addTextChangedListener(textWatcher);
        textinput3.addTextChangedListener(textWatcher);
        textinput4.addTextChangedListener(textWatcher);
        textinput5.addTextChangedListener(textWatcher);
        textinput6.addTextChangedListener(textWatcher);
        textinput7.addTextChangedListener(textWatcher);
        textinput8.addTextChangedListener(textWatcher);
        textinput9.addTextChangedListener(textWatcher);
        textinput10.addTextChangedListener(textWatcher);
        textinput11.addTextChangedListener(textWatcher);
        textinput12.addTextChangedListener(textWatcher);
        textinput13.addTextChangedListener(textWatcher);
        textinput14.addTextChangedListener(textWatcher);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isConnect.setTextColor(Color.rgb(240, 80, 60));
                isConnect.setText("Не подключено");

                if(sender.connect()){
                    conect_flag = true;
                    sender.TMRinit();
                }
                if(conect_flag == true) {
                    isConnect.setTextColor(Color.rgb(80, 240, 60));
                    isConnect.setText("Подключено");
                    sender.disconnect();
                    sender.connect();
                    sender.TMRinit();
                }
            }
        });
    }
}

