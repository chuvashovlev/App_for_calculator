package com.example.myapplication;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

import android.Manifest;

public class BluetoothSender {
    String msg="1";
    Timer myTimer;
    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothSocket mBluetoothSocket;
    private BluetoothDevice mBluetoothDevice;
    private OutputStream mOutputStream;
    private Context mContext; // добавленная переменная
    private final UUID SERIAL_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    public BluetoothSender(Context context, String DEVICE_MAC_ADDRESS) { // добавленный параметр context в конструкторе
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        mBluetoothDevice = mBluetoothAdapter.getRemoteDevice(DEVICE_MAC_ADDRESS);
        mContext = context; // инициализация переменной mContext
    }

    public boolean connect() {
        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Log.e("bluetooth", "Bluetooth is not enabled.");
            return false;
        }

        if (mBluetoothDevice == null) {
            Log.e("bluetooth", "Bluetooth device is null.");
            return false;
        }

        // Check for BLUETOOTH permission
        if (ContextCompat.checkSelfPermission(mContext, Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
            Log.e("bluetooth", "BLUETOOTH permission is not granted.");
            return false;
        }

        try {
            mBluetoothSocket = mBluetoothDevice.createRfcommSocketToServiceRecord(SERIAL_UUID);
            mBluetoothSocket.connect();
            mOutputStream = mBluetoothSocket.getOutputStream();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void SendMessage(final String message) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                //connect();
                try {
                    mOutputStream.write(message.getBytes());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                //disconnect();
            }
        }).start();
    }
    public void disconnect() {
        try {
            mBluetoothSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendMessage(String str){
        msg=str;
    }

    private void timerTick() {
        disconnect();
        connect();
        SendMessage(msg);
    }

    public void TMRinit(){
        myTimer = new Timer();
        myTimer.schedule(new TimerTask() {
            public void run() {
                timerTick();
            }
        }, 0, 500); // каждая 1 секунда
    }
}
